package androtrainer;

public class Ranges
{
	public static final int C_ALLOC=0;
	public static final int C_HEAP=1;
	public static final int JAVA_HEAP=2;
	public static final int ANONYMOUS=3;
	public static final int CODE_APP=4;
}
