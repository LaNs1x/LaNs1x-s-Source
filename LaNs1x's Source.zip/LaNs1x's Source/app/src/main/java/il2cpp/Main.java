package il2cpp;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.StrictMode;
import android.text.Html;
import android.widget.LinearLayout;
import android.widget.Toast;
import il2cpp.typefaces.AlertInput;
import il2cpp.typefaces.CustomArrow;
import il2cpp.typefaces.CustomButton;
import il2cpp.typefaces.CustomSlider;
import il2cpp.typefaces.Hwid;
import il2cpp.typefaces.Menu;
import il2cpp.typefaces.SwitchButton;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import il2cpp.typefaces.CfgSystem;
import android.content.res.AssetManager;

public class Main {
	protected static Context context;
	protected LinearLayout childOfScroll;
	
	public static boolean hide;
	
	
	private static native String[] getFeatures();
	private static native void OnChange(int feature, int value, String strv, boolean check);
	public static native String getTitle();
	
	public static void init(final Context context) {
		Handler handler = new Handler();
		handler.postDelayed(new Runnable() {
			@Override
			public void run() {
				
				System.loadLibrary("LaNs1x");
				
				try {
					new Main().MenuMain(context);
				} catch(Exception e) {
					Toast.makeText(context, e.toString(), Toast.LENGTH_LONG).show();
				}
			}
		}, 1000);
	}
	
	private int num(String txt) {
		return Integer.parseInt(txt);
	}
	
	public final void MenuMain(final Context context) {
		
		Main.context = context;
		
		final Menu menu = new Menu(context);
		//menu.setTitle(getTitle());
		
		int pageId = 0;
		
		String[] listFT = getFeatures();
		
		for (int i = 0; i < listFT.length; i++) {
			final int feature = i;
			String str = listFT[i];
			final String[] split = str.split("_");
			menu.setSize();
			
			// SLIDER_Page_Feature_Text_Max_Current
			// BUTTON_Page_Line_Feature_Text_Size
			
			if (split[0].equals("PAGE")) {
				menu.newPage(pageId, split[1], "j", 1);
				pageId++;
			} else if (split[0].equals("SWITCH")) {
				menu.newSwitch(num(split[1]), num(split[2]), split[3], new SwitchButton.switchChange() {
					public void onClick(int feat, int checked, boolean check) {
						OnChange(feat, checked, "", check);
					} 
				}); 
			} else if (split[0].equals("SLIDER")) {
				menu.newSlider(num(split[1]), num(split[2]), split[3], num(split[4]), num(split[5]), new CustomSlider.sliderChange() {
					public void onChange(int feat, int value) {
						OnChange(feat, value, "", false);
					}
				});
			} else if (split[0].equals("BUTTON")) {
				menu.newButton(num(split[1]), num(split[2]), split[3], new CustomButton.buttonClick() {
					public void onClick(int feat) {
						OnChange(feat, 0, "", false);
					}
				});
			} else if (split[0].equals("INPUT")) {
				menu.newInput(num(split[1]), num(split[2]), split[3], new AlertInput.onChange() {
					public void onPut(String text) {
						OnChange(num(split[2]), 0, text, false);
					}
				});
			} else if (split[0].equals("TITLE")) {
				menu.newText(num(split[1]), split[2]);
			} else if (split[0].equals("LINK")) {
				menu.newLink(num(split[1]), split[2], split[3]);
			}
		}
		if (pageId != 0) {
			menu.showPage(0);
		}
		
		} 
}

