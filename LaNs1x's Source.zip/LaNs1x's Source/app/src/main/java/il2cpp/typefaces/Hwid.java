package il2cpp.typefaces;

import android.content.Context;
import android.os.StrictMode;
import android.provider.Settings.Secure;
import android.util.Base64;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.UUID;

public class Hwid {
	
	public static String getHwid(Context context) {    					
		String hwid = Secure.getString(context.getContentResolver(), Secure.ANDROID_ID);
		return hwid;
	}
	
	public static String getFingerprint() {
        return android.os.Build.FINGERPRINT;
    }
	public static String getHardware() {
        return android.os.Build.HARDWARE;
    }

    public static String getHost() {
        return android.os.Build.HOST;
    }

    public static String getManufacturer() {
        return android.os.Build.MANUFACTURER;
    }

    public static String getModel() {
        return android.os.Build.MODEL;
    }

    public static String getOsVersion() {
        return android.os.Build.VERSION.RELEASE;
    }

    public static String getProduct() {
        return android.os.Build.PRODUCT;
    }

    public static String getUniqueEventId() {
        return UUID.randomUUID().toString();
    }
	
	public static String getBase(String text) {
		String base64 = "?";
		try
		{
			byte[] data = text.getBytes("UTF-8");
			base64 = Base64.encodeToString(data, Base64.DEFAULT);
		} catch (UnsupportedEncodingException e) {}
		return base64;
	}
	
	public static String getMD5(final String text) {
		final String md5 = "MD5";
		try {
			// Create MD5 Hash
			MessageDigest digest = java.security.MessageDigest
                .getInstance(md5);
			digest.update(text.getBytes());
			byte messageDigest[] = digest.digest();

			// Create Hex String
			StringBuilder hexString = new StringBuilder();
			for (byte aMessageDigest : messageDigest) {
				String h = Integer.toHexString(0xFF & aMessageDigest);
				while (h.length() < 2)
					h = "0" + h;
				hexString.append(h);
			}
			return hexString.toString();

		} catch (NoSuchAlgorithmException e) {
			return e.toString();
		}
		// return "?";
	}
	
	public static String reverseString(String str){
		StringBuilder sb = new StringBuilder(str);
		sb.reverse();
		return sb.toString();
	}
	
	public static String getCode(Context context) {
		return String.format("|%s|%s|%s|%s|%s|%s|%s|%s|", getHwid(context), getModel(), getOsVersion(), getManufacturer(), getFingerprint(), getHost(), getHardware(), getProduct());
	}
	
}
