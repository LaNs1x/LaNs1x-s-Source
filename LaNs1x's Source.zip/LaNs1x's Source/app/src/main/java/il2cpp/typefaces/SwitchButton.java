package il2cpp.typefaces;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.CompoundButton;

public class SwitchButton {
	private Context context;
	private String buttonText;
	public boolean isChecked = false;
	
	private int COLOR1, COLOR2, COLOR3, COLOR4;
	private int featureid;
	
	private LinearLayout line;
	private TextView text;
	
	private switchChange callback;
	
	private Typeface font;
	
	public static interface switchChange {
		void onClick(int featureid, int ischeck, boolean checks);
	}
	
	public int dpi(float dp) {
		float scale = context.getResources().getDisplayMetrics().density;
		return (int) (dp * scale + 0.5f);
	}
	
	public void setChecked(boolean isCheck) {
		isChecked = isCheck;
		callback.onClick(featureid, isChecked ? 1 : 0, isCheck);
		GradientDrawable btn = new GradientDrawable();
		
		if (isCheck) {
			btn.setColor(Color.parseColor("#322F42"));
		}
		line.setBackgroundDrawable(btn);
	}
	
	public SwitchButton(Context _ctx, int feature, String _text, float size, switchChange call) {
		context = _ctx;
		buttonText = _text;
		callback = call;
		featureid = feature;
		
		this.COLOR1 = Color.parseColor("#F2F2F2");
		this.COLOR2 = Color.parseColor("#C7C7C7");
		this.COLOR3 = Color.parseColor("#F04C4D");
		this.COLOR4 = Color.parseColor("#FF8281");
		
		font = Typeface.createFromAsset(context.getAssets(), "LANS1X/Font.ttf");
		
		line = new LinearLayout(context);
		line.setLayoutParams(new LinearLayout.LayoutParams(-1, dpi(20)));
		line.setOrientation(LinearLayout.HORIZONTAL);
		line.setGravity(Gravity.CENTER_VERTICAL);
		
		text = new TextView(context);
		text.setText(buttonText);
		text.setTextSize(size);
		text.setTypeface(font);
		text.setGravity(Gravity.CENTER);
		text.setTextColor(Color.WHITE);
		
		OnClickListener clck = new OnClickListener() {
			@Override
			public void onClick(View v) {
				setChecked(!isChecked);
			}
		};
		// button.setOnClickListener(clck);
		line.setOnClickListener(clck);
		
		line.setPadding(0, 0, 0, 0);
		
		line.addView(text, -1, -1);
	}
	
	public LinearLayout getLine() {
		return line;
	}
	
}
