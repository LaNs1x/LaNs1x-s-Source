#include <pthread.h>
#include <jni.h>
#include <Includes/Utils.h>
#include <Substrate/SubstrateHook.h>
#include "KittyMemory/MemoryPatch.h"
#include <Icon.h>
#include <vector>
#include "RGB.h"
#include "Quaternion2.h"

#include "Canvas/ESP.h"
#include "Canvas/Bools.h"
#include "Canvas/StructsCommon.h"

extern "C" {

char* libName = "libil2cpp.so";
ESP espOverlay;

struct My_Patches {MemoryPatch Noclip, MoveBT, BuyZone, Attach, NoSpawn;} hexPatches;
// меняй ник сдесь
JNIEXPORT jstring JNICALL
Java_il2cpp_Main_getTitle(JNIEnv *env, jobject activityObject) {
	return env->NewStringUTF("LANS1X");
}

/*НОРКА ПОШЕЛ НАХУЙ*/


std::string jstring2string(JNIEnv *env, jstring jStr) {
    if (!jStr)
        return "";

    const jclass stringClass = env->GetObjectClass(jStr);
    const jmethodID getBytes = env->GetMethodID(stringClass, "getBytes", "(Ljava/lang/String;)[B");
    const jbyteArray stringJbytes = (jbyteArray) env->CallObjectMethod(jStr, getBytes, env->NewStringUTF("UTF-8"));

    size_t length = (size_t) env->GetArrayLength(stringJbytes);
    jbyte* pBytes = env->GetByteArrayElements(stringJbytes, NULL);

    std::string ret = std::string((char *)pBytes, length);
    env->ReleaseByteArrayElements(stringJbytes, pBytes, JNI_ABORT);

    env->DeleteLocalRef(stringJbytes);
    env->DeleteLocalRef(stringClass);
    return ret;
}

void hexChange(bool &var, MemoryPatch &patch) {
	var = !var;
	if (var) {
		patch.Modify();
	} else {
		patch.Restore();
	}
}

std::string to_string(int param)
{
    std::string str = "";
    for(str = ""; param ; param /= 10)
        str += (char)('0' + param % 10);
    reverse(str.begin(), str.end());
	if (str == "") str = "0";
    return str;
}

std::string fto_string(float param) {
	std::string str = "";
	int num = (int) (param * 100);
	str = to_string(num);
	if (str.size() > 2) str.insert(str.size() - 2, ",");
	return str;
}

JNIEXPORT jobjectArray  JNICALL
Java_il2cpp_Main_getFeatures(JNIEnv *env, jobject activityObject) { jobjectArray ret;
    // PAGE_Name_Icon
	// SWITCH_Page_Feature_Text
	// SLIDER_Page_Feature_Text_Max_Current
	// BUTTON_Page_Feature_Text
	// INPUT_Page_Feature_Text
	// TITLE_Page_Text
	// LINK_Page_Text_Link
	
    //кнопки
    
    
    const char *features[] = {
            "PAGE_Player",   // 0 вкладки
			"PAGE_Visuals", // 1 вкладки
            "PAGE_Skins",  //2 вкладки
			
			"TITLE_0_Functions_13", //хз как называется
			"SWITCH_0_1_Test_13",  //кнопка
			"BUTTON_0_2_TEST BUTTON_13", //кнопка другая
			"SLIDER_0_3_SLIDER_100_50_13",// слайдер
			"INPUT_0_4_Input value", // инпат
			"LINK_0_Creator_https://t.me/lans1x_blyat", // кнопка с ссылкой
            "INPUT_2_6_Input value"  //  тож инпат
    };

    int Total_Feature = (sizeof features /
                         sizeof features[0]); //Now you dont have to manually update the number everytime;

    ret = (jobjectArray) env->NewObjectArray(Total_Feature, env->FindClass("java/lang/String"),
                                             env->NewStringUTF(""));
    int i;
    for (i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));
    return (ret);
} 

JNIEXPORT void JNICALL
Java_il2cpp_Main_OnChange(JNIEnv *env, jobject activityObject, jint feature, jint value, jstring strv, jboolean check) {jobjectArray ret;
	std::string str_value = jstring2string(env, strv);
	switch (feature) {
		
	}
}

JNIEXPORT void JNICALL
Java_il2cpp_typefaces_Menu_DrawOn(JNIEnv *env, jclass type, jobject espView, jobject canvas) {
	espOverlay = ESP(env, espView, canvas);
	if (espOverlay.isValid()){
		
	}
} 

}
// ---------- Hooking ---------- //

void *LANS1X(void *) {
	
    ProcMap il2cppMap;
    do {
        il2cppMap = KittyMemory::getLibraryMap(libName);
        sleep(1);
    } while (!isLibraryLoaded(libName));
	
    return NULL;
}

JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *globalEnv;
    vm->GetEnv((void **) &globalEnv, JNI_VERSION_1_6);
	
	_JavaVM* publicJVM = vm; 
	publicJVM->GetEnv((void **) &globalEnv, JNI_VERSION_1_6); 
	
    // чтобы игра не фризила ок
    pthread_t ptid;
    pthread_create(&ptid, NULL, LANS1X, NULL);

    return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL
JNI_OnUnload(JavaVM *vm, void *reserved) {}
